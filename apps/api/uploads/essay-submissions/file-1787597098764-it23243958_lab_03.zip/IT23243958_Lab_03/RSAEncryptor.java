package test;

// Bouncy Castle security provider
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import java.util.Base64;
import java.util.Scanner;

public class RSAEncryptor {

    // Register the Bouncy Castle provider when the class is loaded
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    // RSA key size used for key-pair generation
    private static final int RSA_KEY_SIZE = 3072;

    public static void main(String[] args) {
        // Read a short plaintext message from the user
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a short message to encrypt: ");
            String message = scanner.nextLine();

            // Record the start time for RSA key generation
            long keyStart = System.nanoTime();

            // Create an RSA key-pair generator using the Bouncy Castle provider
            KeyPairGenerator generator =
                    KeyPairGenerator.getInstance("RSA", "BC");

            // Set the RSA key size
            generator.initialize(RSA_KEY_SIZE);

            // Generate the public/private RSA key pair
            KeyPair keyPair = generator.generateKeyPair();

            // Record the end time for key generation
            long keyEnd = System.nanoTime();

            // Create an RSA cipher using OAEP padding with SHA-256
            Cipher cipher =
                    Cipher.getInstance(
                            "RSA/ECB/OAEPWithSHA-256AndMGF1Padding",
                            "BC"
                    );

            // Initialize the cipher for encryption using the public key
            cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());

            // Measure the time taken to encrypt the message
            long encStart = System.nanoTime();

            // Convert the plaintext message to bytes and encrypt it
            byte[] encrypted =
                    cipher.doFinal(message.getBytes(StandardCharsets.UTF_8));

            long encEnd = System.nanoTime();

            // Initialize the cipher for decryption using the private key
            cipher.init(Cipher.DECRYPT_MODE, keyPair.getPrivate());

            // Measure the time taken to decrypt the message
            long decStart = System.nanoTime();

            // Decrypt the ciphertext
            byte[] decrypted = cipher.doFinal(encrypted);

            long decEnd = System.nanoTime();

            // Display the RSA key size used
            System.out.println();
            System.out.println("RSA key size: " + RSA_KEY_SIZE + " bits");

            // Convert encrypted binary data to Base64 so it can be displayed as text
            System.out.println("Encrypted text (Base64):");
            System.out.println(Base64.getEncoder().encodeToString(encrypted));

            // Convert the decrypted bytes back to a readable string
            System.out.println();
            System.out.println("Decrypted text:");
            System.out.println(new String(decrypted, StandardCharsets.UTF_8));

            // Display the time taken for key generation
            System.out.printf(
                    "%nKey generation time: %.3f ms%n",
                    (keyEnd - keyStart) / 1_000_000.0
            );

            // Display the time taken for encryption
            System.out.printf(
                    "Encryption time: %.3f ms%n",
                    (encEnd - encStart) / 1_000_000.0
            );

            // Display the time taken for decryption
            System.out.printf(
                    "Decryption time: %.3f ms%n",
                    (decEnd - decStart) / 1_000_000.0
            );

        } catch (Exception e) {
            // Print details if any error occurs
            e.printStackTrace();
        } finally {
            // Close the Scanner to release the input resource
            scanner.close();
        }
    }
}
